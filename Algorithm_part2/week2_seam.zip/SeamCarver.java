/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Picture;

import java.awt.Color;

public class SeamCarver {

    private Picture copy;
    private int width;
    private int height;

    public SeamCarver(Picture picture) {
        if (picture == null) throw new IllegalArgumentException("null object!");
        copy = new Picture(picture);
        width = copy.width();
        height = copy.height();
    }

    public Picture picture() {
        Picture res = new Picture(width, height);
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                res.set(c, r, copy.get(c, r));
            }
        }
        return res;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public double energy(int x, int y) {
        coordCheckX(x);
        coordCheckY(y);
        if (x == 0 || x == width - 1 || y == 0 || y == height - 1) {
            return 1000.0;
        }
        else {
            int delX = gradient(x - 1, y, x + 1, y);
            int delY = gradient(x, y - 1, x, y + 1);
            return Math.sqrt(delX + delY);
        }
    }

    private int gradient(int x1, int y1, int x2, int y2) {
        Color c1 = copy.get(x1, y1);
        Color c2 = copy.get(x2, y2);
        int r = c2.getRed() - c1.getRed();
        int g = c2.getGreen() - c1.getGreen();
        int b = c2.getBlue() - c1.getBlue();
        return r * r + g * g + b * b;
    }

    public int[] findHorizontalSeam() {
        double[][] energyArray = new double[width][height];
        for (int i = 0; i < height; i++) energyArray[0][i] = energy(0, i);
        int[][] edgeTo = new int[width][height];
        // StdOut.println("Hi");

        for (int j = 1; j < width; j++) {
            for (int i = 0; i < height; i++) {
                updateParentHorizontal(j, i, energyArray, edgeTo);
            }
        }

        double leastEnergy = Double.POSITIVE_INFINITY;
        int idx = -1;
        for (int i = 0; i < height; i++) {
            if (energyArray[width - 1][i] < leastEnergy) {
                idx = i;
                leastEnergy = energyArray[width - 1][i];
            }
        }
        // StdOut.println("working");

        int[] seam = new int[width];
        seam[width - 1] = idx;
        for (int j = width - 2; j >= 0; j--) {
            seam[j] = seam[j + 1] + edgeTo[j + 1][seam[j + 1]];
        }
        // StdOut.println("here");
        return seam;
    }

    private void updateParentHorizontal(int j, int i, double[][] energyArray, int[][] edgeTo) {
        double midPathEnergy = energyArray[j - 1][i];
        double upPathEnergy = Double.POSITIVE_INFINITY;
        double downPathEnergy = Double.POSITIVE_INFINITY;

        if (i > 0) upPathEnergy = energyArray[j - 1][i - 1];
        if (i < height - 1) downPathEnergy = energyArray[j - 1][i + 1];

        int parent = compare3Num(upPathEnergy, midPathEnergy, downPathEnergy);
        edgeTo[j][i] = parent;
        // StdOut.println("i" + i + "j" + j + "parent" + parent + "downEnergy" + downPathEnergy);
        energyArray[j][i] = energy(j, i) + energyArray[j - 1][i + parent];
    }

    public int[] findVerticalSeam() {
        double[][] energyArray = new double[width][height];
        for (int j = 0; j < width; j++) energyArray[j][0] = energy(j, 0);
        int[][] edgeTo = new int[width][height];

        for (int i = 1; i < height; i++) {
            for (int j = 0; j < width; j++) {
                updateParentVertical(j, i, energyArray, edgeTo);
            }
        }

        double leastEnergy = Double.POSITIVE_INFINITY;
        int idx = -1;
        for (int j = 0; j < width; j++) {
            if (energyArray[j][height - 1] < leastEnergy) {
                idx = j;
                leastEnergy = energyArray[j][height - 1];
            }
        }

        int[] seam = new int[height];
        seam[height - 1] = idx;
        for (int i = height - 2; i >= 0; i--) {
            seam[i] = seam[i + 1] + edgeTo[seam[i + 1]][i + 1];
        }
        return seam;
    }

    private void updateParentVertical(int j, int i, double[][] energyArray, int[][] edgeTo) {
        double midPathEnergy = energyArray[j][i - 1];
        double leftPathEnergy = Double.POSITIVE_INFINITY;
        double rightPathEnergy = Double.POSITIVE_INFINITY;

        if (j > 0) leftPathEnergy = energyArray[j - 1][i - 1];
        if (j < width - 1) rightPathEnergy = energyArray[j + 1][i - 1];

        int parent = compare3Num(leftPathEnergy, midPathEnergy, rightPathEnergy);
        edgeTo[j][i] = parent;
        energyArray[j][i] = energy(j, i) + energyArray[j + parent][i - 1];
    }

    private int compare3Num(double left, double mid, double right) {
        if (mid <= left && mid <= right) {
            return 0;
        }
        else if (left <= mid && left <= right) {
            return -1;
        }
        else {
            return 1;
        }
    }

    public void removeHorizontalSeam(int[] seam) {
        if (seam == null) throw new IllegalArgumentException("null object!");
        if (height <= 1)
            throw new IllegalArgumentException("height of pic is equal to or less than 1");
        if (seam.length != width)
            throw new IllegalArgumentException("Horizontal seam length is not correct.");
        for (int i = 0; i < (seam.length - 1); i++) {
            coordCheckY(seam[i]);
            if (Math.abs(seam[i] - seam[i + 1]) > 1)
                throw new IllegalArgumentException("adjacent entries differ by more than 1.");
        }
        coordCheckY(seam[seam.length - 1]);
        for (int c = 0; c < width; c++) {
            for (int r = seam[c]; r < height - 1; r++) {
                copy.set(c, r, copy.get(c, r + 1));
            }
        }
        height -= 1;
    }

    public void removeVerticalSeam(int[] seam) {
        if (seam == null) throw new IllegalArgumentException("null object!");
        if (width <= 1)
            throw new IllegalArgumentException("width of pic is equal to or less than 1");
        if (seam.length != height)
            throw new IllegalArgumentException("Vertical seam length is not correct.");
        for (int i = 0; i < (seam.length - 1); i++) {
            coordCheckX(seam[i]);
            if (Math.abs(seam[i] - seam[i + 1]) > 1)
                throw new IllegalArgumentException("adjacent entries differ by more than 1.");
        }
        coordCheckX(seam[seam.length - 1]);
        for (int r = 0; r < height; r++) {
            for (int c = seam[r]; c < width - 1; c++) {
                copy.set(c, r, copy.get(c + 1, r));
            }
        }
        width -= 1;
    }

    private void coordCheckX(int x) {
        if (x < 0 || x >= width) throw new IllegalArgumentException("x coord out of range");
    }

    private void coordCheckY(int y) {
        if (y < 0 || y >= height) throw new IllegalArgumentException("y coord out of range");
    }

    public static void main(String[] args) {

    }
}
