/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class SAP {

    private static BreadthFirstDirectedPaths bfsFromV;
    private static BreadthFirstDirectedPaths bfsFromW;
    private Digraph copyG;
    private int numV;

    public SAP(Digraph G) {
        if (G == null) throw new IllegalArgumentException("null object");
        copyG = new Digraph(G);
        numV = G.V();
    }

    private void isVertexValid(int v) {
        if (v < 0 || v >= numV) throw new IllegalArgumentException("invalid vertex index");
    }

    private void isVertexSetValid(Iterable<Integer> v) {
        if (v == null) throw new IllegalArgumentException("null object");
        for (int w : v) isVertexValid(w);
    }

    public int length(int v, int w) {
        isVertexValid(v);
        isVertexValid(w);
        int ancestor = ancestor(v, w);
        if (ancestor == -1) return -1;
        return bfsFromV.distTo(ancestor) + bfsFromW.distTo(ancestor);
    }

    public int ancestor(int v, int w) {
        isVertexValid(v);
        isVertexValid(w);
        bfsFromV = new BreadthFirstDirectedPaths(copyG, v);
        bfsFromW = new BreadthFirstDirectedPaths(copyG, w);
        int res = -1;
        int length = numV * 2;
        for (int i = 0; i < numV; i++) {
            if (bfsFromV.hasPathTo(i) && bfsFromW.hasPathTo(i)) {
                if (bfsFromV.distTo(i) + bfsFromW.distTo(i) < length) {
                    res = i;
                    length = bfsFromV.distTo(i) + bfsFromW.distTo(i);
                }
            }
        }
        return res;
    }

    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        isVertexSetValid(v);
        isVertexSetValid(w);
        int ancestor = ancestor(v, w);
        if (ancestor == -1) return -1;
        return bfsFromV.distTo(ancestor) + bfsFromW.distTo(ancestor);
    }

    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        isVertexSetValid(v);
        isVertexSetValid(w);
        bfsFromV = new BreadthFirstDirectedPaths(copyG, v);
        bfsFromW = new BreadthFirstDirectedPaths(copyG, w);
        int res = -1;
        int length = numV * 2;
        for (int i = 0; i < numV; i++) {
            if (bfsFromV.hasPathTo(i) && bfsFromW.hasPathTo(i)) {
                if (bfsFromV.distTo(i) + bfsFromW.distTo(i) < length) {
                    res = i;
                    length = bfsFromV.distTo(i) + bfsFromW.distTo(i);
                }
            }
        }
        return res;
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        Digraph G = new Digraph(in);
        SAP sap = new SAP(G);
        while (!StdIn.isEmpty()) {
            int v = StdIn.readInt();
            int w = StdIn.readInt();
            int length = sap.length(v, w);
            int ancestor = sap.ancestor(v, w);
            StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
        }
    }
}
