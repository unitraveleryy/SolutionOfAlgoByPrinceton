/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.DirectedCycle;
import edu.princeton.cs.algs4.In;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class WordNet {

    private Map<String, Set<Integer>> noun2Id;
    private Map<Integer, String> id2Noun;
    private int numV = 0;
    private SAP sap;

    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null)
            throw new IllegalArgumentException("null argument(s)!");
        noun2Id = new HashMap<>();
        id2Noun = new HashMap<>();
        readSynsets(synsets);
        // StdOut.println("synsets reading is done");
        readHypernyms(hypernyms);
        // StdOut.println("hypernyms reading is done");
    }

    private void readSynsets(String synsets) {
        In in = new In(synsets);
        String line = null;
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) continue; /* skip some lines */
            numV += 1;

            int indexV = Integer.parseInt(strs[0]);
            id2Noun.put(indexV, strs[1]);
            String[] syns = strs[1].split(" ");
            // parse the synsets
            for (String nouns : syns) {
                if (noun2Id.containsKey(nouns)) noun2Id.get(nouns).add(indexV);
                else {
                    Set<Integer> temp = new HashSet<Integer>();
                    temp.add(indexV);
                    noun2Id.put(nouns, temp);
                }
            }
        }
    }

    private void readHypernyms(String hypernyms) {
        In in = new In(hypernyms);
        Digraph G = new Digraph(numV);
        String line = null;
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) continue; /* skip some lines */

            int child = Integer.parseInt(strs[0]);
            // constructing digraph
            for (int i = 1; i < strs.length; i++) {
                G.addEdge(child, Integer.parseInt(strs[i]));
            }
        }
        // StdOut.println("digraph construction is done");
        sap = new SAP(G);
        // cycle detection
        DirectedCycle dect = new DirectedCycle(G);
        if (dect.hasCycle()) throw new IllegalArgumentException("cycle detected!");

        // only one root check
        boolean onlyOneRoot = false;
        for (int i = 0; i < G.V(); i++) {
            if (G.outdegree(i) == 0) {
                if (onlyOneRoot)
                    throw new IllegalArgumentException("More than 1 root for the WorldNet");
                else onlyOneRoot = true;
            }
        }
    }

    public Iterable<String> nouns() {
        return noun2Id.keySet();
    }

    public boolean isNoun(String word) {
        if (word == null) throw new IllegalArgumentException("word passed-in is null!");
        return noun2Id.containsKey(word);
    }

    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null) throw new IllegalArgumentException("null argument(s)");
        if (isNoun(nounA) && isNoun(nounB)) {
            Iterable<Integer> idA = noun2Id.get(nounA);
            Iterable<Integer> idB = noun2Id.get(nounB);
            int dis = sap.length(idA, idB);
            return dis;
        }
        else {
            throw new IllegalArgumentException("noun(s) is not in the WordNet!");
        }
    }

    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null) throw new IllegalArgumentException("null argument(s)");
        if (isNoun(nounA) && isNoun(nounB)) {
            Iterable<Integer> idA = noun2Id.get(nounA);
            Iterable<Integer> idB = noun2Id.get(nounB);
            int ans = sap.ancestor(idA, idB);
            return id2Noun.get(ans);
        }
        else {
            throw new IllegalArgumentException("noun(s) is not in the WordNet!");
        }
    }

    public static void main(String[] args) {
        if (args.length > 1) {
            WordNet wordNet = new WordNet(args[0], args[1]);
            wordNet.isNoun("a");
        }
    }
}
