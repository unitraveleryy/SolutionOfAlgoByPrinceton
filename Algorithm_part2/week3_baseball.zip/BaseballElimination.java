/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.FlowEdge;
import edu.princeton.cs.algs4.FlowNetwork;
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BaseballElimination {
    private int teamNum;
    private final int[] wNum;
    private final int[] lNum;
    private final int[] rNum;
    private final int[][] gAgainst;
    private final Map<String, Integer> team2Idx;
    private final Map<Integer, String> idx2Team;
    private int maxWin = 0;
    private int maxWinTeamIdx = -1;
    private final Set<String> certificate;
    private int forwardCapcity;

    public BaseballElimination(String filename) {
        In in = new In(filename);
        teamNum = in.readInt();
        wNum = new int[teamNum];
        lNum = new int[teamNum];
        rNum = new int[teamNum];
        gAgainst = new int[teamNum][teamNum];
        team2Idx = new HashMap<>();
        idx2Team = new HashMap<>();
        certificate = new HashSet<>();
        for (int i = 0; i < teamNum; i++) {
            String teamName = in.readString();
            wNum[i] = in.readInt();
            if (wNum[i] > maxWin) {
                maxWin = wNum[i];
                maxWinTeamIdx = i;
            }
            lNum[i] = in.readInt();
            rNum[i] = in.readInt();
            team2Idx.put(teamName, i);
            idx2Team.put(i, teamName);
            for (int j = 0; j < teamNum; j++) {
                gAgainst[i][j] = in.readInt();
            }
        }
    }

    public int numberOfTeams() {
        return teamNum;
    }

    public Iterable<String> teams() {
        return team2Idx.keySet();
    }

    public int wins(String team) {
        if (team2Idx.containsKey(team))
            return wNum[team2Idx.get(team)];
        else throw new IllegalArgumentException("invalid team name");
    }

    public int losses(String team) {
        if (team2Idx.containsKey(team))
            return lNum[team2Idx.get(team)];
        else throw new IllegalArgumentException("invalid team name");
    }

    public int remaining(String team) {
        if (team2Idx.containsKey(team))
            return rNum[team2Idx.get(team)];
        else throw new IllegalArgumentException("invalid team name");
    }

    public int against(String team1, String team2) {
        if (team2Idx.containsKey(team1) && team2Idx.containsKey(team2))
            return gAgainst[team2Idx.get(team1)][team2Idx.get(team2)];
        else throw new IllegalArgumentException("invalid team name(s)");
    }

    public boolean isEliminated(String team) {
        if (!team2Idx.containsKey(team)) {
            throw new IllegalArgumentException("invalid team name");
        }
        else {
            certificate.clear();
            int id = team2Idx.get(team);
            if (wNum[id] + rNum[id] < maxWin) {
                // trivial elimination
                certificate.add(idx2Team.get(maxWinTeamIdx));
                return true;
            }
            else {
                // nontrivial elimination
                int numV = teamNum * (teamNum - 1) / 2 + teamNum + 1;
                FlowNetwork net = createNet(numV, id);
                FordFulkerson f = new FordFulkerson(net, id, numV - 1);
                if (f.value() < forwardCapcity) {
                    for (int i = 0; i < teamNum; i++) {
                        for (int j = 0; j < i; j++) {
                            if (f.inCut(teamNum + j + sum(i))) {
                                certificate.add(idx2Team.get(i));
                                certificate.add(idx2Team.get(j));
                            }
                        }
                    }
                    return true;
                }
                else {
                    return false;
                }
            }
        }
    }

    private FlowNetwork createNet(int numV, int id) {
        FlowNetwork net = new FlowNetwork(numV);
        forwardCapcity = 0;
        for (int i = 0; i < teamNum; i++) {
            if (i == id) continue;
            net.addEdge(new FlowEdge(i, numV - 1, wNum[id] + rNum[id] - wNum[i]));
        }
        for (int i = 0; i < teamNum; i++) {
            if (i == id) continue;
            for (int j = 0; j < i; j++) {
                if (j == id) continue;
                if (gAgainst[i][j] > 0) {
                    forwardCapcity += gAgainst[i][j];
                    net.addEdge(new FlowEdge(id, teamNum + j + sum(i), gAgainst[i][j]));
                    net.addEdge(new FlowEdge(teamNum + j + sum(i), i, Double.POSITIVE_INFINITY));
                    net.addEdge(new FlowEdge(teamNum + j + sum(i), j, Double.POSITIVE_INFINITY));
                }
            }
        }
        return net;
    }

    private int sum(int i) {
        return i * (i - 1) / 2;
    }

    public Iterable<String> certificateOfElimination(String team) {
        if (!team2Idx.containsKey(team)) {
            throw new IllegalArgumentException("invalid team name");
        }
        else {
            boolean temp = isEliminated(team);
            return temp ? certificate : null;
        }
    }

    public static void main(String[] args) {
        BaseballElimination division = new BaseballElimination(args[0]);
        for (String team : division.teams()) {
            if (division.isEliminated(team)) {
                StdOut.print(team + " is eliminated by the subset R = { ");
                for (String t : division.certificateOfElimination(team)) {
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            }
            else {
                StdOut.println(team + " is not eliminated");
            }
        }
    }
}
