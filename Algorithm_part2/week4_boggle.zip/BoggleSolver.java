/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashSet;
import java.util.Set;

public class BoggleSolver {

    private TrieNode root;
    private int[] delI = new int[] { 0, 0, 1, -1, 1, 1, -1, -1 };
    private int[] delJ = new int[] { 1, -1, 0, 0, 1, -1, 1, -1 };

    private class TrieNode {
        private TrieNode[] next = new TrieNode[26];
        private boolean isString = false;
    }

    public BoggleSolver(String[] dictionary) {
        root = new TrieNode();
        for (String s : dictionary) {
            root = put(root, s, 0);
        }
    }

    private TrieNode put(TrieNode x, String s, int d) {
        if (x == null) x = new TrieNode();
        if (d == s.length()) {
            x.isString = true;
            return x;
        }
        char c = s.charAt(d);
        x.next[c - 'A'] = put(x.next[c - 'A'], s, d + 1);
        return x;
    }

    public Iterable<String> getAllValidWords(BoggleBoard board) {
        Set<String> words = new HashSet<>();
        for (int i = 0; i < board.rows(); i++) {
            for (int j = 0; j < board.cols(); j++) {
                StringBuilder word = new StringBuilder();
                boolean[][] visited = new boolean[board.rows()][board.cols()];
                dfs(root, word, i, j, words, board, visited);
            }
        }
        return words;
    }

    private void dfs(TrieNode cur, StringBuilder s, int i, int j, Set<String> words,
                     BoggleBoard board, boolean[][] visited) {
        if (!visited[i][j] && cur != null) {
            char c = board.getLetter(i, j);
            if (cur.next[c - 'A'] != null) {
                if (c == 'Q') {
                    if (cur.next[c - 'A'].next['U' - 'A'] != null) {
                        s.append('Q');
                        s.append('U');
                        // if (cur.next[c - 'A'].next['U' - 'A'].isString && s.length() > 2)
                        // words.add(s.toString());
                        cur = cur.next[c - 'A'].next['U' - 'A'];
                        if (cur.isString && s.length() > 2) words.add(s.toString());
                        visited[i][j] = true;
                        for (int k = 0; k < delI.length; k++) {
                            if (coordCheck(i + delI[k], j + delJ[k], board)) {
                                dfs(cur, s, i + delI[k], j + delJ[k], words, board, visited);
                            }
                        }
                        visited[i][j] = false;
                        s.deleteCharAt(s.length() - 1);
                        s.deleteCharAt(s.length() - 1);
                    }
                }
                else {
                    s.append(c);
                    // if (cur.next[c - 'A'].isString && s.length() > 2)
                    cur = cur.next[c - 'A'];
                    if (cur.isString && s.length() > 2) words.add(s.toString());
                    visited[i][j] = true;
                    for (int k = 0; k < delI.length; k++) {
                        if (coordCheck(i + delI[k], j + delJ[k], board)) {
                            dfs(cur, s, i + delI[k], j + delJ[k], words, board, visited);
                        }
                    }
                    visited[i][j] = false;
                    s.deleteCharAt(s.length() - 1);
                }
            }
        }
    }

    private boolean coordCheck(int i, int j, BoggleBoard board) {
        if (i < 0 || i >= board.rows()) return false;
        if (j < 0 || j >= board.cols()) return false;
        return true;
    }

    public int scoreOf(String word) {
        if (!containWord(word)) return 0;
        int[] scoreList = new int[] { 0, 0, 1, 1, 2, 3, 5 };
        if (word.length() <= 7) return scoreList[word.length() - 1];
        else return 11;
    }

    private boolean containWord(String word) {
        TrieNode x = get(root, word, 0);
        if (x == null) return false;
        return x.isString;
    }

    private TrieNode get(TrieNode cur, String s, int d) {
        if (cur == null) return null;
        if (d == s.length()) return cur;
        char c = s.charAt(d);
        return get(cur.next[c - 'A'], s, d + 1);
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
        // StdOut.println(solver.containWord("A"));
        // StdOut.println(solver.scoreOf("BROKE"));
    }
}
