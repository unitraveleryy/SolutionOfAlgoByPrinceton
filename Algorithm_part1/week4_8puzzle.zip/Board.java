/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private final int size;
    private final int[][] boardCopy;
    private final int[][] boardGoal;
    private int blankIndexI;
    private int blankIndexJ;

    public Board(int[][] tiles) {
        this.size = tiles.length;
        this.boardCopy = copyBlocks(tiles);
        this.boardGoal = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                this.boardGoal[i][j] = i * size + j + 1;
                if (boardCopy[i][j] == 0) {
                    this.blankIndexI = i;
                    this.blankIndexJ = j;
                }
            }
        }
    }

    private int[][] copyBlocks(int[][] src) {
        int[][] copy = new int[size][size];
        for (int i = 0; i < size; i++) {
            System.arraycopy(src[i], 0, copy[i], 0, size);
        }
        return copy;
    }

    public String toString() {
        String res = "";
        res += size;
        for (int i = 0; i < size; i++) {
            res += "\n";
            String curr = "";
            for (int j = 0; j < size; j++) {
                curr += " ";
                curr += boardCopy[i][j];
            }
            res += curr;
        }
        return res;
    }

    public int dimension() {
        return size;
    }

    public int hamming() {
        int res = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (boardCopy[i][j] == 0) continue;
                if (boardCopy[i][j] != boardGoal[i][j]) res += 1;
            }
        }
        return res;
    }

    public int manhattan() {
        int res = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                int cur = boardCopy[i][j];
                if (cur == 0) continue;
                int goalI = (cur - 1) / size;
                int goalJ = cur - goalI * size - 1;
                res += Math.abs(i - goalI) + Math.abs(j - goalJ);
            }
        }
        return res;
    }

    public boolean isGoal() {
        return hamming() == 0;
    }

    public boolean equals(Object y) {
        if (y == null) return false;
        if (y == this) return true;
        if (y.getClass() != this.getClass()) return false;
        Board that = (Board) y;
        if (that.dimension() != size) return false;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (boardCopy[i][j] != that.boardCopy[i][j]) return false;
            }
        }
        return true;
    }

    public Iterable<Board> neighbors() {
        // StdOut.println("Board copy before adding neighbors");
        // StdOut.println(new Board(boardCopy));
        List<Board> res = new ArrayList<>();
        if (blankIndexI > 0) res.add(new Board(swapBlankWithIJ(blankIndexI - 1, blankIndexJ)));
        if (blankIndexI < size - 1)
            res.add(new Board(swapBlankWithIJ(blankIndexI + 1, blankIndexJ)));
        if (blankIndexJ > 0) res.add(new Board(swapBlankWithIJ(blankIndexI, blankIndexJ - 1)));
        if (blankIndexJ < size - 1)
            res.add(new Board(swapBlankWithIJ(blankIndexI, blankIndexJ + 1)));
        return res;
    }

    private int[][] swapBlankWithIJ(int i, int j) {
        int[][] res = copyBlocks(boardCopy);
        int temp = res[i][j];
        res[blankIndexI][blankIndexJ] = temp;
        res[i][j] = 0;
        return res;
    }

    public Board twin() {
        // StdOut.println("Board copy before creating twins");
        // StdOut.println(new Board(boardCopy));
        if (blankIndexI < size - 1) {
            if (blankIndexJ < size - 1) return new Board(
                    swapAnyTwoSliders(blankIndexI + 1, blankIndexJ, blankIndexI, blankIndexJ + 1));
            else return new Board(
                    swapAnyTwoSliders(blankIndexI + 1, blankIndexJ, blankIndexI, blankIndexJ - 1));
        }
        else {
            if (blankIndexJ < size - 1) return new Board(
                    swapAnyTwoSliders(blankIndexI - 1, blankIndexJ, blankIndexI, blankIndexJ + 1));
            else return new Board(
                    swapAnyTwoSliders(blankIndexI - 1, blankIndexJ, blankIndexI, blankIndexJ - 1));
        }
    }

    private int[][] swapAnyTwoSliders(int i1, int j1, int i2, int j2) {
        int[][] res = copyBlocks(boardCopy);
        int temp = res[i1][j1];
        res[i1][j1] = res[i2][j2];
        res[i2][j2] = temp;
        return res;
    }


    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);
        StdOut.println(initial);
        StdOut.println(initial.twin());
        for (Board s : initial.neighbors()) {
            StdOut.println(s);
        }
    }
}
