/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {

    private boolean isSolvable = false;
    private int steps = -1;
    private Stack<Board> sol;

    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException("null borad object");
        MinPQ<Node> pq = new MinPQ<>();
        MinPQ<Node> pqTwin = new MinPQ<>();
        Node first = new Node(initial, 0, null);
        Node firstTwin = new Node(initial.twin(), 0, null);
        pq.insert(first);
        pqTwin.insert(firstTwin);
        Node out = pq.delMin();
        Node outTwin = pqTwin.delMin();
        boolean success = out.currBoard.isGoal();
        boolean successTwin = outTwin.currBoard.isGoal();
        while (!success && !successTwin) {
            for (Board nei : out.currBoard.neighbors()) {
                if (out.parent != null && nei.equals(out.parent.currBoard)) continue;
                pq.insert(new Node(nei, out.moves + 1, out));
            }
            for (Board nei : outTwin.currBoard.neighbors()) {
                if (outTwin.parent != null && nei.equals(outTwin.parent.currBoard)) continue;
                pqTwin.insert(new Node(nei, out.moves + 1, outTwin));
            }
            out = pq.delMin();
            outTwin = pqTwin.delMin();
            success = out.currBoard.isGoal();
            successTwin = outTwin.currBoard.isGoal();
        }

        if (success) {
            this.isSolvable = true;
            this.steps = out.moves;
            this.sol = new Stack<>();
            Node curr = out;
            while (curr != null) {
                this.sol.push(curr.currBoard);
                curr = curr.parent;
            }
        }

    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public int moves() {
        return steps;
    }

    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        return sol;
    }

    private class Node implements Comparable<Node> {
        public Board currBoard;
        public int dis;
        public int moves;
        public Node parent;

        public Node(Board b, int moves, Node parent) {
            this.currBoard = b;
            this.moves = moves;
            this.parent = parent;
            this.dis = b.manhattan();
        }

        public int compareTo(Node that) {
            int weight1 = this.dis + this.moves;
            int weight2 = that.dis + that.moves;
            return Integer.compare(weight1, weight2);
        }

    }

    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
