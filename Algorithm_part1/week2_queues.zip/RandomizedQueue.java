/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] q;
    private int size;

    public RandomizedQueue() {
        this.q = (Item[]) new Object[5];
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException("null object cannot be enqueued");
        if (size == q.length) {
            resize(2 * q.length);
        }
        q[size] = item;
        size += 1;
    }

    private void resize(int len) {
        Item[] resizeArray = (Item[]) new Object[len];
        for (int i = 0; i < size(); i++) {
            resizeArray[i] = q[i];
        }
        q = resizeArray;
    }

    public Item dequeue() {
        if (isEmpty())
            throw new NoSuchElementException("queue is already empty! no element can be dequeued");
        int id = StdRandom.uniform(size);
        Item res = q[id];
        if (id != size - 1) q[id] = q[size - 1];
        q[size - 1] = null;
        size -= 1;

        if (size > 1 && size <= q.length / 4) resize(q.length / 2);

        return res;
    }

    public Item sample() {
        if (isEmpty())
            throw new NoSuchElementException("queue is already empty! no element can be sampled");
        int id = StdRandom.uniform(size);
        return q[id];
    }

    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {
        private final int[] visitSeq;
        private int current = 0;

        public RandomizedQueueIterator() {
            this.visitSeq = new int[size];
            for (int i = 0; i < size; i++) {
                visitSeq[i] = i;
            }
            StdRandom.shuffle(visitSeq);
        }

        public boolean hasNext() {
            return current != visitSeq.length;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException("No element can be iterated!");
            Item res = q[visitSeq[current]];
            current += 1;
            return res;
        }

        public void remove() {
            throw new UnsupportedOperationException("This action is not supported!");
        }
    }

    public static void main(String[] args) {
        RandomizedQueue<Integer> que = new RandomizedQueue<>();
        System.out.println("size: " + que.size());
        System.out.println("empty: " + que.isEmpty());

        que.enqueue(1);
        System.out.println("size: " + que.size());
        System.out.println("empty: " + que.isEmpty());

        que.enqueue(2);
        que.enqueue(3);
        que.enqueue(4);
        que.enqueue(5);
        que.enqueue(6);
        que.enqueue(7);
        que.enqueue(8);
        que.enqueue(9);
        que.enqueue(10);
        System.out.println(que.dequeue());
        System.out.println(que.dequeue());
        System.out.println(que.dequeue());
        System.out.println(que.dequeue());
        System.out.println("size: " + que.size());
        System.out.println("empty: " + que.isEmpty());
        for (int s : que) {
            StdOut.println(s);
        }
        for (int s : que) {
            StdOut.println(s);
        }
        // for (int s : que) {
        //     StdOut.println(s);
        //     for (int j : que) {
        //         StdOut.println(j);
        //     }
        // }
    }
}
