/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private Node first;
    private Node last;
    private int size;

    public Deque() {
        this.size = 0;
    }

    private class Node {
        Item item;
        Node next = null;
        Node prev = null;

        public Node(Item item) {
            this.item = item;
        }
    }

    public boolean isEmpty() {
        return first == null || last == null;
    }

    public int size() {
        return size;
    }

    public void addFirst(Item item) {
        if (item == null) throw new IllegalArgumentException("A null reference is added!");
        size += 1;
        Node oldfirst = first;
        first = new Node(item);
        if (isEmpty()) last = first;
        else {
            first.next = oldfirst;
            oldfirst.prev = first;
        }
    }

    public void addLast(Item item) {
        if (item == null) throw new IllegalArgumentException("A null reference is added!");
        size += 1;
        Node oldlast = last;
        last = new Node(item);
        if (isEmpty()) first = last;
        else {
            oldlast.next = last;
            last.prev = oldlast;
        }
    }

    public Item removeFirst() {
        if (isEmpty()) throw new NoSuchElementException(
                "The queue is already empty. No element can be removed!");
        size -= 1;
        Item item = first.item;
        first = first.next;
        if (isEmpty()) last = null;
        else first.prev = null;
        return item;
    }

    public Item removeLast() {
        if (isEmpty()) throw new NoSuchElementException(
                "The queue is already empty. No element can be removed!");
        size -= 1;
        Item item = last.item;
        last = last.prev;
        if (isEmpty()) first = null;
        else last.next = null;
        return item;
    }

    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        private Node current = first;

        public boolean hasNext() {
            return current != null;
        }

        public void remove() {
            throw new UnsupportedOperationException("This action is not supported!");
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException("No element can be iterated");
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

    public static void main(String[] args) {
        Deque<Integer> test = new Deque<>();
        StdOut.println(test.isEmpty());
        test.addFirst(2);
        test.addFirst(1);
        test.addLast(3);
        test.addLast(4);
        for (int s : test) {
            StdOut.println(s);
        }
        StdOut.println(test.removeFirst());
        StdOut.println(test.removeFirst());
        StdOut.println(test.removeLast());
        StdOut.println(test.removeLast());
        StdOut.println(test.isEmpty());
    }
}
