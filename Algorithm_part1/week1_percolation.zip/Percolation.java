/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private int size;
    private boolean[] openOrNot;
    private int numOfOpened;
    private WeightedQuickUnionUF unionFind;

    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException("Grid size needs to be a positive number");
        this.size = n;
        this.unionFind = new WeightedQuickUnionUF(n * n + 2);
        this.openOrNot = new boolean[n * n + 1];
        this.numOfOpened = 0;
    }

    public void open(int row, int col) {
        coordCheck(row, col);
        if (!isOpen(row, col)) {
            int id = rowColTo1D(row, col);
            openOrNot[id] = true;
            numOfOpened += 1;
            if (row == 1) unionFind.union(0, id);
            if (row == size) unionFind.union(id, size * size + 1);
            if (row > 1 && isOpen(row - 1, col)) unionFind.union(id, rowColTo1D(row - 1, col));
            if (row < size && isOpen(row + 1, col)) unionFind.union(id, rowColTo1D(row + 1, col));
            if (col > 1 && isOpen(row, col - 1)) unionFind.union(id, rowColTo1D(row, col - 1));
            if (col < size && isOpen(row, col + 1)) unionFind.union(id, rowColTo1D(row, col + 1));
        }
    }

    public boolean isOpen(int row, int col) {
        coordCheck(row, col);
        return openOrNot[rowColTo1D(row, col)];
    }

    public boolean isFull(int row, int col) {
        coordCheck(row, col);
        return unionFind.find(0) == unionFind.find(rowColTo1D(row, col));
    }

    public int numberOfOpenSites() {
        return numOfOpened;
    }

    public boolean percolates() {
        return unionFind.find(0) == unionFind.find(size * size + 1);
    }

    private int rowColTo1D(int row, int col) {
        return (row - 1) * size + col;
    }

    private void coordCheck(int row, int col) {
        if (row <= 0 || row > size)
            throw new IllegalArgumentException("Row index out of bounds");
        if (col <= 0 || col > size)
            throw new IllegalArgumentException("Column index out of bounds");
    }

    public static void main(String[] args) {
        Percolation test = new Percolation(5);
        test.open(1, 1);
        test.open(1, 2);
        test.open(2, 2);
        test.open(2, 3);
        test.open(3, 3);
        test.open(3, 4);
        test.open(4, 4);
        test.open(5, 5);
        test.open(4, 5);
        test.open(4, 5);
        test.open(4, 5);
        test.open(4, 5);
        System.out.println(test.numberOfOpenSites());
        System.out.println(test.percolates());
    }
}
