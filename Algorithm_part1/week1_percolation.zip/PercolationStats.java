/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private double[] hisPercolate;

    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0)
            throw new IllegalArgumentException("Both arguments need to be positive");
        this.hisPercolate = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation grid = new Percolation(n);
            while (!grid.percolates()) {
                int row = StdRandom.uniform(1, n + 1);
                int col = StdRandom.uniform(1, n + 1);
                grid.open(row, col);
            }
            hisPercolate[i] = grid.numberOfOpenSites() * 1.0 / (n * n);
        }
    }

    public double mean() {
        return StdStats.mean(hisPercolate);
    }

    public double stddev() {
        return StdStats.stddev(hisPercolate);
    }

    public double confidenceLo() {
        return mean() - 1.96 * stddev() / Math.sqrt(hisPercolate.length);
    }

    public double confidenceHi() {
        return mean() + 1.96 * stddev() / Math.sqrt(hisPercolate.length);
    }

    public static void main(String[] args) {
        int n = StdIn.readInt();
        int trials = StdIn.readInt();
        PercolationStats test = new PercolationStats(n, trials);
        StdOut.println("mean                    = " + test.mean());
        StdOut.println("stddev                  = " + test.stddev());
        StdOut.println("95% confidence interval = " + "[" + test.confidenceLo() + ", " + test
                .confidenceHi() + "]");
    }
}
