/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {

    private LineSegment[] res;

    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("null obeject for constructor!");
        int num = points.length;
        for (int i = 0; i < num; i++) {
            if (points[i] == null) throw new IllegalArgumentException("There's null point");
            for (int j = i + 1; j < num; j++) {
                if (points[j] == null) throw new IllegalArgumentException("There's null point");
                if (points[i].compareTo(points[j]) == 0)
                    throw new IllegalArgumentException("repeated points!");
            }
        }
        if (num < 4) {
            res = new LineSegment[0];
            return;
        }
        Point[] lAux = points.clone();
        ArrayList<LineSegment> temp = new ArrayList<>();
        for (int p = 0; p < num; p++) {
            Point curr = points[p];
            // StdOut.println(curr);
            Arrays.sort(lAux, curr.slopeOrder());
            double curSlope = lAux[0].slopeTo(curr);
            int cnt = 1;
            int i = 1;
            while (i < num) {
                while (i - 1 + cnt < num && lAux[i - 1 + cnt].slopeTo(curr) == curSlope) {
                    cnt += 1;
                }
                if (cnt >= 3) {
                    Arrays.sort(lAux, i - 1, i - 1 + cnt);
                    // StdOut.println(i - 1);
                    // StdOut.println(cnt);
                    if (curr.compareTo(lAux[i - 1]) < 0)
                        temp.add(new LineSegment(curr, lAux[i - 1 + cnt - 1]));
                }
                if (i - 1 + cnt == num) break;
                curSlope = lAux[i - 1 + cnt].slopeTo(curr);
                i = i + cnt;
                cnt = 1;
            }
        }
        res = temp.toArray(new LineSegment[temp.size()]);
    }

    public int numberOfSegments() {
        return res.length;
    }

    public LineSegment[] segments() {
        return res.clone();
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
