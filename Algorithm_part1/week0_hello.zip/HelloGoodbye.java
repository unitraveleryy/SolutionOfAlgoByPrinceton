/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class HelloGoodbye {
    public static void main(String[] args) {
        String p1 = args[0];
        String p2 = args[1];
        System.out.println("Hello " + p1 + " and " + p2 + ".");
        System.out.println("Goodbye " + p2 + " and " + p1 + ".");
    }
}
