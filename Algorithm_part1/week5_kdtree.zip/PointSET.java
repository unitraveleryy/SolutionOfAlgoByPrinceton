/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class PointSET {

    private Set<Point2D> pointSet;

    public PointSET() {
        this.pointSet = new TreeSet<>();
    }

    public boolean isEmpty() {
        return pointSet.isEmpty();
    }

    public int size() {
        return pointSet.size();
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        pointSet.add(p);
    }

    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        return pointSet.contains(p);
    }

    public void draw() {
        for (Point2D p : pointSet) {
            p.draw();
        }
    }

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) throw new IllegalArgumentException("null object passed in!");
        List<Point2D> res = new ArrayList<>();
        for (Point2D p : pointSet) {
            if (rect.contains(p)) res.add(p);
        }
        return res;
    }

    public Point2D nearest(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        Point2D res = null;
        double dis = Double.POSITIVE_INFINITY;
        for (Point2D iter : pointSet) {
            if (iter.distanceSquaredTo(p) < dis) {
                res = iter;
                dis = p.distanceSquaredTo(iter);
            }
        }
        return res;
    }

    public static void main(String[] args) {
        PointSET test = new PointSET();
        test.insert(new Point2D(1.0, 2.0));
        test.insert(new Point2D(3.0, 2.0));
        test.insert(new Point2D(4.0, 5.0));
        StdOut.println(test.isEmpty());
        StdOut.println(test.size());
        // test.nearest(new Point2D(1.0, 1.0)).draw();
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.setPenRadius(0.05);
        test.draw();
    }
}
