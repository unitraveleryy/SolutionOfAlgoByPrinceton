/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;

import java.util.ArrayList;
import java.util.List;

public class KdTree {

    private int size;
    private Node root;

    public KdTree() {
    }

    private static class Node {
        private Point2D p;
        private Node lb;
        private Node rt;
        private RectHV rect;

        public Node(Point2D point, RectHV r) {
            this.p = point;
            this.rect = r;
        }
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        if (!contains(p)) {
            this.size += 1;
            this.root = insertHelper(null, this.root, p, true);
        }
    }

    private Node insertHelper(Node prev, Node rootCur, Point2D that, boolean flag) {
        if (rootCur == null) {
            if (prev == null) return new Node(that, new RectHV(0.0, 0.0, 1.0, 1.0));
            else {
                if (flag) {
                    double bound = prev.p.y();
                    if (that.y() < bound)
                        return
                                new Node(that, new RectHV(prev.rect.xmin(), prev.rect.ymin(),
                                                          prev.rect.xmax(), bound));
                    else
                        return
                                new Node(that, new RectHV(prev.rect.xmin(), bound, prev.rect.xmax(),
                                                          prev.rect.ymax()));
                }
                else {
                    double bound = prev.p.x();
                    if (that.x() < bound)
                        return new Node(that,
                                        new RectHV(prev.rect.xmin(), prev.rect.ymin(), bound,
                                                   prev.rect.ymax()));
                    else
                        return new Node(that,
                                        new RectHV(bound, prev.rect.ymin(), prev.rect.xmax(),
                                                   prev.rect.ymax()));
                }
            }
        }
        if (rootCur.p.equals(that)) return rootCur;
        if (flag) {
            if (that.x() < rootCur.p.x())
                rootCur.lb = insertHelper(rootCur, rootCur.lb, that, false);
            else rootCur.rt = insertHelper(rootCur, rootCur.rt, that, false);
        }
        else {
            if (that.y() < rootCur.p.y())
                rootCur.lb = insertHelper(rootCur, rootCur.lb, that, true);
            else rootCur.rt = insertHelper(rootCur, rootCur.rt, that, true);
        }
        return rootCur;
    }

    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        return containsHelper(this.root, p, true);
    }

    private boolean containsHelper(Node rootCur, Point2D that, boolean flag) {
        if (rootCur == null) return false;
        if (rootCur.p.equals(that)) return true;
        else if (flag) {
            if (that.x() < rootCur.p.x()) return containsHelper(rootCur.lb, that, false);
            else return containsHelper(rootCur.rt, that, false);
        }
        else {
            if (that.y() < rootCur.p.y()) return containsHelper(rootCur.lb, that, true);
            else return containsHelper(rootCur.rt, that, true);
        }
    }

    public void draw() {
        drawHelper(this.root, true);
    }

    private void drawHelper(Node rootCur, boolean flag) {
        if (rootCur != null) {
            StdDraw.setPenRadius(0.01);
            StdDraw.setPenColor(StdDraw.BLACK);
            rootCur.p.draw();
            if (flag) {
                Point2D bottom = new Point2D(rootCur.p.x(), rootCur.rect.ymin());
                Point2D upper = new Point2D(rootCur.p.x(), rootCur.rect.ymax());
                StdDraw.setPenRadius(0.005);
                StdDraw.setPenColor(StdDraw.RED);
                bottom.drawTo(upper);
                drawHelper(rootCur.lb, false);
                drawHelper(rootCur.rt, false);
            }
            else {
                Point2D left = new Point2D(rootCur.rect.xmin(), rootCur.p.y());
                Point2D right = new Point2D(rootCur.rect.xmax(), rootCur.p.y());
                StdDraw.setPenRadius(0.005);
                StdDraw.setPenColor(StdDraw.BLUE);
                left.drawTo(right);
                drawHelper(rootCur.lb, true);
                drawHelper(rootCur.rt, true);
            }
        }
    }

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) throw new IllegalArgumentException("null object passed in!");
        List<Point2D> res = new ArrayList<>();
        rangeHelper(rect, root, res);
        return res;
    }

    private void rangeHelper(RectHV rect, Node rootCur, List<Point2D> res) {
        if (rootCur != null) {
            if (rect.contains(rootCur.p)) res.add(rootCur.p);
            if (rootCur.lb != null && rect.intersects(rootCur.lb.rect))
                rangeHelper(rect, rootCur.lb, res);
            if (rootCur.rt != null && rect.intersects(rootCur.rt.rect))
                rangeHelper(rect, rootCur.rt, res);
        }
    }

    public Point2D nearest(Point2D p) {
        if (p == null) throw new IllegalArgumentException("null object passed in!");
        Point2D closest = null;
        Stack<Point2D> s = new Stack<>();
        s.push(closest);
        nearestHelper(p, this.root, s, true);
        return s.pop();
    }

    private void nearestHelper(Point2D query, Node rootCur, Stack<Point2D> s, boolean flag) {
        double disRes;
        Point2D res = s.peek();
        if (res == null) disRes = Double.POSITIVE_INFINITY;
        else disRes = res.distanceSquaredTo(query);
        if (rootCur != null && rootCur.rect.distanceSquaredTo(query) <= disRes) {
            if (rootCur.p.distanceSquaredTo(query) < disRes) {
                s.pop();
                s.push(rootCur.p);
            }
            if (flag) {
                if (query.x() < rootCur.p.x()) {
                    nearestHelper(query, rootCur.lb, s, false);
                    nearestHelper(query, rootCur.rt, s, false);
                }
                else {
                    nearestHelper(query, rootCur.rt, s, false);
                    nearestHelper(query, rootCur.lb, s, false);
                }
            }
            else {
                if (query.y() < rootCur.p.y()) {
                    nearestHelper(query, rootCur.lb, s, true);
                    nearestHelper(query, rootCur.rt, s, true);
                }
                else {
                    nearestHelper(query, rootCur.rt, s, true);
                    nearestHelper(query, rootCur.lb, s, true);
                }
            }
        }
    }

    // private void debug(Point2D p1) {
    //     p1 = new Point2D(0.5, 0.5);
    //     This is not correct, reference has gone, no actions can be made on p1
    // }
    //
    // private Point2D de() {
    //     Point2D p0 = new Point2D(0.6, 0.6);
    //     debug(p0);
    //     return p0;
    // }


    public static void main(String[] args) {
        Point2D p1 = new Point2D(0.1, 0.1);
        Point2D p2 = new Point2D(0.2, 0.2);
        Point2D p3 = new Point2D(0.3, 0.3);
        KdTree test = new KdTree();
        test.insert(p1);
        test.insert(p2);
        test.insert(p3);
        // Point2D q = test.nearest(new Point2D(0.01, 0.01));
        // StdOut.println(q == null);
        // Point2D debug = test.de();
        // StdOut.println(debug.x());
    }
}
